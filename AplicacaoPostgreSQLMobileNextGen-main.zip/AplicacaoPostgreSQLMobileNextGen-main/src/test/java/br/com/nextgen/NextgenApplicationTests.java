package br.com.nextgen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NextgenApplicationTests {

	@Test
	void contextLoads() {
	}

}
