package br.com.nextgen.Entities;

public enum Permissoes {
	ROOT,
    ADMIN,
    DEFAULT,
    VIEW
}
