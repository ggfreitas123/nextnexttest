package br.com.nextgen.Entities;

public enum UnidadeMedida {
	HECTARE,
	QUILOMETROS_QUADRADOS,
	METROS_QUADRADO
}
