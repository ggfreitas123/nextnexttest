package br.com.nextgen.Repository;

import br.com.nextgen.Entities.Umidade;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UmidadeRepository extends JpaRepository<Umidade, Long> {
}
