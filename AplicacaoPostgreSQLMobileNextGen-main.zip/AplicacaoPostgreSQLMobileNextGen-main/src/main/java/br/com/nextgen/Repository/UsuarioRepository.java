package br.com.nextgen.Repository;

import java.util.UUID;
import br.com.nextgen.Entities.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioRepository extends JpaRepository<Usuario, UUID> {
}
